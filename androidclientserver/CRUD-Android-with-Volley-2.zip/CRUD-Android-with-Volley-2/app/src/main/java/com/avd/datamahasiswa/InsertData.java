package com.avd.datamahasiswa;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.avd.datamahasiswa.Util.AppController;
import com.avd.datamahasiswa.Util.ServerAPI;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class InsertData extends AppCompatActivity {
    EditText nama, npm, jurusan, prog_studi, dosen_pa, semester, tahun_ajaran, ip_smt_lalu, jumlah_sks;
    Button btnbatal,btnsimpan;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_data);

        /*get data from intent*/
        Intent data = getIntent();
        final int update = data.getIntExtra("update",0);
        String intent_npm = data.getStringExtra("npm");
        String intent_nama = data.getStringExtra("nama");
        String intent_jurusan = data.getStringExtra("jurusan");
        String intent_prog_studi = data.getStringExtra("prog_studi");
        String intent_dosen_pa = data.getStringExtra("dosen_pa");
        String intent_semester = data.getStringExtra("semester");
        String intent_tahun_ajaran = data.getStringExtra("tahun_ajaran");
        String intent_ip_smt_lalu = data.getStringExtra("ip_smt_lalu");
        String intent_jumlah_sks = data.getStringExtra("jumlah_sks");
        /*end get data from intent*/

        nama = (EditText) findViewById(R.id.inp_nama);
        npm = (EditText) findViewById(R.id.inp_npm);
        jurusan = (EditText) findViewById(R.id.inp_jurusan);
        prog_studi = (EditText) findViewById(R.id.inp_prog_studi);
        dosen_pa = (EditText) findViewById(R.id.inp_dosen_pa);
        semester = (EditText) findViewById(R.id.inp_semester);
        tahun_ajaran = (EditText) findViewById(R.id.inp_tahun_ajaran);
        ip_smt_lalu = (EditText) findViewById(R.id.inp_ip_smt_lalu);
        jumlah_sks = (EditText) findViewById(R.id.inp_jumlah_sks);
        btnbatal = (Button) findViewById(R.id.btn_cancel);
        btnsimpan = (Button) findViewById(R.id.btn_simpan);
        pd = new ProgressDialog(InsertData.this);

        /*kondisi update / insert*/
        if(update == 1)
        {
            btnsimpan.setText("Update Data");
            npm.setText(intent_npm);
            nama.setText(intent_nama);
            jurusan.setText(intent_jurusan);
            prog_studi.setText(intent_prog_studi);
            dosen_pa.setText(intent_dosen_pa);
            semester.setText(intent_semester);
            tahun_ajaran.setText(intent_tahun_ajaran);
            ip_smt_lalu.setText(intent_ip_smt_lalu);
            jumlah_sks.setText(intent_jumlah_sks);
        }


        btnsimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(update == 1)
                {
                    Update_data();
                }else {
                    simpanData();
                }
            }
        });

        btnbatal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent main = new Intent(InsertData.this,MainActivity.class);
                startActivity(main);
            }
        });
    }

    private void Update_data()
    {
        pd.setMessage("Update Data");
        pd.setCancelable(false);
        pd.show();

        StringRequest updateReq = new StringRequest(Request.Method.POST, ServerAPI.URL_UPDATE,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.cancel();
                        try {
                            JSONObject res = new JSONObject(response);
                            Toast.makeText(InsertData.this, ""+   res.getString("message") , Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        startActivity( new Intent(InsertData.this,MainActivity.class));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.cancel();
                        Toast.makeText(InsertData.this, "Gagal Insert Data", Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("nama",nama.getText().toString());
                map.put("npm",npm.getText().toString());
                map.put("jurusan",jurusan.getText().toString());
                map.put("prog_studi",prog_studi.getText().toString());
                map.put("dosen_pa",dosen_pa.getText().toString());
                map.put("semester",semester.getText().toString());
                map.put("tahun_ajaran",tahun_ajaran.getText().toString());
                map.put("ip_smt_lalu",ip_smt_lalu.getText().toString());
                map.put("jumlah_sks",jumlah_sks.getText().toString());
                return map;
            }
        };

        AppController.getInstance().addToRequestQueue(updateReq);
    }



    private void simpanData()
    {

        pd.setMessage("Menyimpan Data");
        pd.setCancelable(false);
        pd.show();

        StringRequest sendData = new StringRequest(Request.Method.POST, ServerAPI.URL_INSERT,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pd.cancel();
                        try {
                            JSONObject res = new JSONObject(response);
                            Toast.makeText(InsertData.this, ""+   res.getString("message") , Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        startActivity( new Intent(InsertData.this,MainActivity.class));
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.cancel();
                        Toast.makeText(InsertData.this, "Gagal Insert Data", Toast.LENGTH_SHORT).show();
                    }
                }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("nama",nama.getText().toString());
                map.put("npm",npm.getText().toString());
                map.put("jurusan",jurusan.getText().toString());
                map.put("prog_studi",prog_studi.getText().toString());
                map.put("dosen_pa",dosen_pa.getText().toString());
                map.put("semester",semester.getText().toString());
                map.put("tahun_ajaran",tahun_ajaran.getText().toString());
                map.put("ip_smt_lalu",ip_smt_lalu.getText().toString());
                map.put("jumlah_sks",jumlah_sks.getText().toString());

                return map;
            }
        };

        AppController.getInstance().addToRequestQueue(sendData);
    }
}
