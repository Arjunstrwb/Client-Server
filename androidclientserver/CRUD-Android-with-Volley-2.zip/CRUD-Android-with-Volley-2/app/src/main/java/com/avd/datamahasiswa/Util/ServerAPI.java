package com.avd.datamahasiswa.Util;

/**
 * Created by hakiki95 on 11/30/2016.
 */

public class ServerAPI {
    public static final String URL_DATA = "http://arjuncs.dx.am/view_data.php";
    public static final String URL_INSERT = "http://arjuncs.dx.am/create_data.php";
    public static final String URL_DELETE = "http://arjuncs.dx.am/delete_data.php";
    public static final String URL_UPDATE = "http://arjuncs.dx.am/update_data.php";
}
