package com.avd.datamahasiswa.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.avd.datamahasiswa.InsertData;
import com.avd.datamahasiswa.Model.ModelData;
import com.avd.datamahasiswa.R;

import java.util.List;

/**
 * Created by hakiki95 on 11/30/2016.
 */

public class AdapterData extends RecyclerView.Adapter<AdapterData.HolderData> {
    private List<ModelData> mItems ;
    private Context context;

    public AdapterData (Context context, List<ModelData> items)
    {
        this.mItems = items;
        this.context = context;
    }

    @Override
    public HolderData onCreateViewHolder(ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_row,parent,false);
        HolderData holderData = new HolderData(layout);
        return holderData;
    }

    @Override
    public void onBindViewHolder(HolderData holder, int position) {
        ModelData md  = mItems.get(position);
        holder.tvnama.setText(md.getNama());
        holder.tvnpm.setText(md.getNpm());
        holder.tvjurusan.setText(md.getJurusan());
        holder.tvprog_studi.setText(md.getProg_studi());
        holder.tvdosen_pa.setText(md.getDosen_pa());
        holder.tvsemester.setText(md.getSemester());
        holder.tvtahun_ajaran.setText(md.getTahun_ajaran());
        holder.tvip_smt_lalu.setText(md.getIp_smt_lalu());
        holder.tvjumlah_sks.setText(md.getJumlah_sks());
        holder.md = md;


    }

    @Override
    public int getItemCount() {
        return mItems.size();
    }


    class HolderData extends RecyclerView.ViewHolder
    {
        TextView tvnama,tvnpm, tvjurusan, tvprog_studi, tvdosen_pa, tvsemester, tvtahun_ajaran, tvip_smt_lalu, tvjumlah_sks;
        ModelData md;

        public  HolderData (View view)
        {
            super(view);

            tvnama = (TextView) view.findViewById(R.id.nama);
            tvnpm = (TextView) view.findViewById(R.id.npm);
            tvjurusan = (TextView) view.findViewById(R.id.jurusan);
            tvprog_studi = (TextView) view.findViewById(R.id.prog_studi);
            tvdosen_pa = (TextView) view.findViewById(R.id.dosen_pa);
            tvsemester = (TextView) view.findViewById(R.id.semester);
            tvtahun_ajaran = (TextView) view.findViewById(R.id.tahun_ajaran);
            tvip_smt_lalu = (TextView) view.findViewById(R.id.ip_smt_lalu);
            tvjumlah_sks = (TextView) view.findViewById(R.id.jumlah_sks);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent update = new Intent(context, InsertData.class);
                    update.putExtra("update",1);
                    update.putExtra("nama",md.getNama());
                    update.putExtra("npm",md.getNpm());
                    update.putExtra("jurusan",md.getJurusan());
                    update.putExtra("prog_studi",md.getProg_studi());
                    update.putExtra("dosen_pa",md.getDosen_pa());
                    update.putExtra("semester",md.getSemester());
                    update.putExtra("tahun_ajaran",md.getTahun_ajaran());
                    update.putExtra("ip_smt_lalu",md.getIp_smt_lalu());
                    update.putExtra("jumlah_sks",md.getJumlah_sks());
                    context.startActivity(update);
                }
            });
        }
    }
}
