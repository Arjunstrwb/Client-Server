package com.avd.datamahasiswa.Model;

/**
 * Created by hakiki95 on 11/30/2016.
 */

public class ModelData {
    String nama, npm, jurusan, prog_studi, dosen_pa, semester, tahun_ajaran, ip_smt_lalu, jumlah_sks;

    public ModelData(){}

    public ModelData(String nama, String npm, String jurusan, String prog_studi, String dosen_pa, String semester, String tahun_ajaran, String ip_smt_lalu, String jumlah_sks) {
        this.nama = nama;
        this.npm = npm;
        this.jurusan = jurusan;
        this.prog_studi = prog_studi;
        this.dosen_pa = dosen_pa;
        this.semester = semester;
        this.tahun_ajaran = tahun_ajaran;
        this.ip_smt_lalu = ip_smt_lalu;
        this.jumlah_sks = jumlah_sks;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) { this.nama = nama; }


    public String getNpm() { return npm; }

    public void setNpm(String npm) { this.npm = " - "+npm; }


    public String getJurusan() { return jurusan; }

    public void setJurusan(String jurusan) { this.jurusan = " - "+jurusan; }


    public String getProg_studi() { return prog_studi; }

    public void setProg_studi(String prog_studi) { this.prog_studi = " - "+prog_studi; }


    public String getDosen_pa() {
        return dosen_pa;
    }

    public void setDosen_pa(String dosen_pa) { this.dosen_pa = " - "+dosen_pa; }


    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) { this.semester = " - "+semester; }


    public String getTahun_ajaran() {
        return tahun_ajaran;
    }

    public void setTahun_ajaran(String tahun_ajaran) { this.tahun_ajaran = " - "+tahun_ajaran; }


    public String getIp_smt_lalu() {
        return ip_smt_lalu;
    }

    public void setIp_smt_lalu(String ip_smt_lalu) { this.ip_smt_lalu = " - "+ip_smt_lalu; }


    public String getJumlah_sks() {
        return jumlah_sks;
    }

    public void setJumlah_sks(String jumlah_sks) { this.jumlah_sks = " - "+jumlah_sks; }
}
